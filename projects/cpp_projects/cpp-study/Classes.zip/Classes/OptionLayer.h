//
//  OptionLayer.h
//  cpp-study
//
//  Created by Yueming Zhang on 14-6-15.
//
//

#ifndef __cpp_study__OptionLayer__
#define __cpp_study__OptionLayer__

#include <cocos2d.h>

class OptionLayer : public cocos2d::Layer
{
public:
    OptionLayer();
    ~OptionLayer();
    
    virtual bool init();
    
    CREATE_FUNC(OptionLayer);
};

#endif /* defined(__cpp_study__OptionLayer__) */
