//
//  GameLayer.cpp
//  cpp-study
//
//  Created by Yueming Zhang on 14-6-15.
//
//

#include "GameLayer.h"
using namespace cocos2d;


GameLayer::GameLayer(){}

GameLayer::~GameLayer(){}


bool GameLayer::init()
{

    bool ret = false;
    
    do{
    
        CC_BREAK_IF(!Layer::init());
        
        _map = TMXTiledMap::create("pd_tilemap.tmx");
        
        this->addChild(_map);

        ret = true;
        
    }while (0);
        
    return ret;
}