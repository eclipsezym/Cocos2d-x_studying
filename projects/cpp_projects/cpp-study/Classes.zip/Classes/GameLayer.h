//
//  GameLayer.h
//  cpp-study
//
//  Created by Yueming Zhang on 14-6-15.
//
//

#ifndef __cpp_study__GameLayer__
#define __cpp_study__GameLayer__

#include <cocos2d.h>

class GameLayer : public cocos2d::Layer
{
public:
    GameLayer();
    ~GameLayer();
    
    virtual bool init();
    
    CREATE_FUNC(GameLayer);
    
private:
    cocos2d::TMXTiledMap *_map;

};


#endif /* defined(__cpp_study__GameLayer__) */
